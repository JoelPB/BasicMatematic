/*
 * Teste para o aplicativo
 */

package test;

import questoes.Dados;

public class TestDados {

	public static void main(String[] args) {
		
		Dados quest = new Dados();
		
		System.out.println(quest.getNomeM().get(1));
		System.out.println(quest.getNomeM());
		System.out.println(quest.getNomeF().size());
		
	}

}
