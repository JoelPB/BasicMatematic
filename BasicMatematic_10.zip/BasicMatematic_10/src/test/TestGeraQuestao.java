package test;

import questoes.GeraQuestao;

public class TestGeraQuestao {

	public static void main(String[] args) {
		
		//Escolha escolha = new Escolha();
		//Estatistica estatistica =  new Estatistica();
		 GeraQuestao questao = new GeraQuestao();
		 
		System.out.println(questao.questao(1));
				
	}

}
